/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import tablaenteros.TablaEnteros;

/**
 *
 * @author Jose
 * 
 * @BeforeClass TablaEnterosTest
 */
public class TablaEnterosTest {
    
    public TablaEnterosTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testSumaTabla() {
        System.out.println("sumaTabla");
        TablaEnteros instance = null;
        int expResult = 0;
        if (expResult == null) || (expResult== 0){
        	throw testSumaTabla2();
        }
        int result = instance.sumaTabla();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mayorTabla method, of class TablaEnteros.
     */
    @Test
    public void testMayorTabla() {
        System.out.println("mayorTabla");
        TablaEnteros instance = null;
        int expResult = -999;
        int result = instance.mayorTabla();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of posicionTabla method, of class TablaEnteros.
     */
    @Test
    public void testPosicionTabla() {
        System.out.println("posicionTabla");
        int n = 20;
        TablaEnteros instance = null;
        int expResult = 20;
        
        if (n!=n+n) {
        	throw testPosicionTabla2();
        }
        
        int result = instance.posicionTabla(n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testSumaTabla2() {
        System.out.println("sumaTabla");
        TablaEnteros instance = null;
        int expResult = 0;
        if (expResult == null) || (expResult== 0){
        	new IllegalArgumentException("No hay elementos");
        }
        int result = instance.sumaTabla();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    public void testPosicionTabla2() {
        System.out.println("posicionTabla");
        int n = 20;
        TablaEnteros instance = null;
        int expResult = 20;
        
        if (n!=n+n) {
        	new java.util.NoSuchElementException("No existe" + n);
        }
        
        int result = instance.posicionTabla(n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}
