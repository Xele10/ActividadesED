//Ejercicio 1

```flow
st=>start: Inicio
e=>end: Fin
inout1=>inputoutput: Escribir "Introduzca el primer número"
inread1=>inputoutput: Leer numero1
inout2=>inputoutput: Escribir "Introduzca el segundo número"
inread2=>inputoutput: Leer numero2
operation1=> operation: muestra el mayor y menor de los números
numero1>=numero2?
or
numero2>=numero1?
inread=>inputoutput: Leer numero1 and numero2



//Ejercicio 2

```flow
st=>start: Inicio
e=>end: Fin
inout1=>inputoutput: Escribir "Introduzca el primer número"
inread1=>inputoutput: Leer numero1
inout2=>inputoutput: Escribir "Introduzca el segundo número"
inread2=>inputoutput: Leer numero2
condition: condicion
Yes or No?
cond(yes)->numero1>numero2->Restar numero1-numero2
cond (no)->numero2>numero1->Sumar numero2+numero1



//Ejercicio 3

```flow
st=>start: Inicio
e=>end: Fin
inout1=>inputoutput: Escribir "Introduzca el primer número"
inread1=>inputoutput: Leer numero1
inout2=>inputoutput: Escribir "Introduzca el segundo número"
inread2=>inputoutput: Leer numero2
cond=>condition: condicion
operation1: operation: Sumar todos los positivos
until operation1<==0->operation1
cond(yes)->operation1=>=0->operation1
cond (no)->operation1=>=0->e
