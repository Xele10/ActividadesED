/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Jose
 */
public class FechaTest {
    
    public FechaTest() {
    }
    
    @Before
    @BeforeAll
    public static void setUpClass() {
    }
    
    @After
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of DevuelveFecha method, of class Fecha.
     */
    @Test
    public void testDevuelveFecha() {
        System.out.println("DevuelveFecha");
        int tipo = 1;
        Fecha instance = new date();
        
        /* SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = originalFormat.parse(value.toString());
        
        SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatedDate = newFormat.format(date); */
        String cad= "202106"
        		
        if (tipo!=1) || (tipo!=2) || (tipo!=3){
            fail("ERROR");        	
        }
        
        String expResult = "2021/06";
        String result = instance.DevuelveFecha(tipo);
        assertEquals(expResult, result);
          
    }
    
    @Test
    public void testDevuelveFecha() {
        System.out.println("DevuelveFecha");
        int tipo = 2;
        Fecha instance = new date();
        
        /* SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = originalFormat.parse(value.toString());
        
        SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatedDate = newFormat.format(date); */
        String cad= "062021"
        		
        if (tipo!=1) || (tipo!=2) || (tipo!=3){
            fail("ERROR");        	
        }
        
        String expResult = "06/2021";
        String result = instance.DevuelveFecha(tipo);
        assertEquals(expResult, result);
          
    }

    @Test
    public void testDevuelveFecha() {
        System.out.println("DevuelveFecha");
        int tipo = 3;
        Fecha instance = new date();
        
        /* SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = originalFormat.parse(value.toString());
        
        SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatedDate = newFormat.format(date); */
        String cad= "ERROR"
        		
        if (tipo!=1) || (tipo!=2) || (tipo!=3){
            fail("ERROR");        	
        }
        
        String expResult = "ERROR";
        String result = instance.DevuelveFecha(tipo);
        assertEquals(expResult, result);
          
    }

    @Test
    public void testDevuelveFecha() {
        System.out.println("DevuelveFecha");
        int tipo = 4;
        Fecha instance = new date();
        
        /* SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = originalFormat.parse(value.toString());
        
        SimpleDateFormat newFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatedDate = newFormat.format(date); */
        String cad= "ERROR"
        		
        if (tipo!=1) || (tipo!=2) || (tipo!=3){
            fail("ERROR");        	
        }
        
        String expResult = "ERROR";
        String result = instance.DevuelveFecha(tipo);
        assertEquals(expResult, result);
          
    }

}
